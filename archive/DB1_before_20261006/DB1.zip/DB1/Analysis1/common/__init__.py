"""Shared configuration and schemas."""
